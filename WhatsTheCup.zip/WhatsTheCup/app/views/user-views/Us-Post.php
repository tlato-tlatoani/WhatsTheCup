<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/WhatsTheCup/public/css/SidebarUsuario.css">
    <link rel="stylesheet" href="/WhatsTheCup/public/css/Us_Post.css">
    <link rel="stylesheet" href="/WhatsTheCup/public/css/Header.css">
    <link rel="stylesheet" href="/WhatsTheCup/public/css/Fuentes.css">
    <title>Whats The Cup</title>
</head>
<body>


<div id="layout">
    <div id="sidebar-container"></div>

    <div id="layout-inside">
    <div id="publicacion-contenido">

    <div id="titulo">
        <h1>LOREM IPSUM</h1>
        <h2> Autor | 08 de Septiembre 2025</h2>
    </div>

    <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin vulputate vulputate dolor sit amet venenatis. 
        Nam facilisis, velit at vehicula feugiat, enim eros finibus diam, eu aliquet sapien tellus vel mi. 
        Donec rhoncus purus in justo iaculis, nec imperdiet nulla suscipit. In blandit magna arcu, et tincidunt tortor commodo venenatis. 
        In vehicula enim quis elit molestie, id pulvinar lorem tempus. Sed metus leo, maximus a imperdiet in, consequat et turpis. 
        Suspendisse porta, dui ut tincidunt laoreet, arcu ligula sollicitudin arcu, vel vulputate justo diam eu nibh. 
        Praesent suscipit faucibus mauris et suscipit. Aenean ultricies efficitur est, id viverra lacus scelerisque et. 
        Duis eu molestie nunc, id bibendum quam. Proin vulputate scelerisque dui, non varius orci interdum faucibus. 
        Duis viverra molestie velit, sodales feugiat turpis mattis et. Etiam quis sollicitudin metus.
    </p>

    <p>
        Maecenas elementum arcu tellus, nec mattis quam dignissim eu. Sed viverra commodo dui quis tincidunt. In et mollis eros. 
        Proin eu blandit arcu, non ornare ipsum. Nulla eget velit vel elit blandit imperdiet. Integer ultrices purus mauris. Fusce a tortor 
        eget nunc facilisis tempus. Curabitur venenatis sagittis augue, nec bibendum tortor. Quisque dictum, orci eu aliquet placerat, 
        neque dolor bibendum quam, vel rutrum augue massa ut nunc. Sed dictum lacus ornare tortor aliquam viverra. Pellentesque dignissim 
        tortor vel tortor imperdiet scelerisque. Nunc accumsan, tellus sed gravida feugiat, elit odio sagittis ipsum, vel ultricies metus 
        elit sit amet libero. Fusce efficitur, erat ut congue consequat, magna nulla bibendum enim, eget pretium lorem sapien ac ipsum.
    </p>

    <img id="imagen-publicacion">

    <h2 id="categoria">Categoría</h2>
    </div>

    <h3> <i class="bi bi-heart-fill"></i> 10 Likes</h3>
    <hr>


    <div id="comentarios">
    <div id="escribir-comentario">
        <img src="/WhatsTheCup/public/imagenes/FDP.png" class="foto-comentario">
        <input type="text" placeholder="Añade un comentario...">
    </div>
    
   <div class="comentario">
  <img src="/WhatsTheCup/public/imagenes/FDP.png" class="foto-comentario">
  <div class="comentario-contenido">
    <h3>Usuario X</h3>
    <p class="comentario-usuario">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nec volutpat justo. Vestibulum at ante at dolor lacinia sollicitudin. In condimentum laoreet orci luctus tristique.</p>
  </div>
</div>

<div class="comentario">
  <img src="/WhatsTheCup/public/imagenes/FDP.png" class="foto-comentario">
  <div class="comentario-contenido">
    <h3>Usuario X</h3>
    <p class="comentario-usuario">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nec volutpat justo. Vestibulum at ante at dolor lacinia sollicitudin. In condimentum laoreet orci luctus tristique.</p>
  </div>
</div>

    </div>

    </div>


</div>

<h1 id="footer"> Whats The Cup. Todos los derechos reservados </h1>
    
<script src="/WhatsTheCup/public/js/Header.js"></script>
<script src="/WhatsTheCup/public/js/Us_Post.js"></script>

</body>
</html>